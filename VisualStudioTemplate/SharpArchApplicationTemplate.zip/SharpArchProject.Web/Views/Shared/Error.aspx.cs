﻿using System.Web.Mvc;

namespace $safeprojectname$.Views.Shared
{
    public partial class Error : ViewPage
    {
    }
}
