﻿namespace $safeprojectname$
{
    public class ControllerEnums
    {
        public enum GlobalViewDataProperty
        {
            PageMessage
        }
    }
}
