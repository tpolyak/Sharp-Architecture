﻿using Ninject.Core;
using SharpArch.Core.PersistenceSupport;
using SharpArch.Data.NHibernate;

namespace $safeprojectname$.NinjectModules
{
    public class DataModule : StandardModule
    {
        public override void Load() {
            // Add your Ninject bindings here for Repository objects
        }
    }
}
